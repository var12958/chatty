const { GoogleGenerativeAI } = require('@google/generative-ai');
const { retrieveRelevantChunks } = require('../utils/retriever');
const { rerankChunks } = require('../utils/reranker');
const { buildGroundedPrompt, buildOutOfScopeResponse } = require('../utils/promptBuilder');
const { getSession, deleteSession } = require('../utils/vectorStore');

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// In-memory conversation history per session
const conversationHistories = {};

const chat = async (req, res) => {
  try {
    const { userMessage, sessionId } = req.body;

    if (!userMessage || !sessionId) {
      return res.status(400).json({
        error: 'Missing required fields — userMessage and sessionId are required'
      });
    }

    // Get session info
    const session = getSession(sessionId);
    if (!session) {
      return res.status(404).json({
        error: 'Session not found. Please create a new assistant.'
      });
    }

    const { topic, domain } = session;

    // Get or create conversation history
    if (!conversationHistories[sessionId]) {
      conversationHistories[sessionId] = [];
    }
    const history = conversationHistories[sessionId];

    console.log(`\n=== Chat: "${userMessage}" ===`);

    // Step 1 — Retrieve relevant chunks
    const { chunks, isOutOfScope } = await retrieveRelevantChunks(
      sessionId,
      userMessage
    );

    // Step 2 — If out of scope return early
    if (isOutOfScope) {
      const outOfScopeMsg = buildOutOfScopeResponse(topic);
      history.push({ type: 'user', text: userMessage });
      history.push({ type: 'ai', text: outOfScopeMsg });

      return res.status(200).json({
        reply: outOfScopeMsg,
        isOutOfScope: true,
        sessionId
      });
    }

    // Step 3 — Re-rank chunks
    const topChunks = rerankChunks(chunks, userMessage, 3);

    // Step 4 — Build grounded prompt
    const prompt = buildGroundedPrompt(
      topic,
      domain,
      topChunks,
      history,
      userMessage
    );

    // Step 5 — Call Gemini
    const model = genAI.getGenerativeModel({ model: 'gemini-pro' });
    const result = await model.generateContent(prompt);
    const reply = result.response.text();

    // Step 6 — Save to history
    history.push({ type: 'user', text: userMessage });
    history.push({ type: 'ai', text: reply });

    // Keep history to last 10 messages only
    if (history.length > 10) {
      conversationHistories[sessionId] = history.slice(-10);
    }

    console.log(`=== Response generated ===\n`);

    return res.status(200).json({
      reply,
      isOutOfScope: false,
      sources: topChunks.map(c => ({ title: c.title, source: c.source, url: c.url })),
      sessionId
    });

  } catch (err) {
    console.error('Chat error:', err.message);

    if (err.message.includes('quota') || err.message.includes('rate limit')) {
      return res.status(429).json({ error: 'API rate limit reached — please wait and try again' });
    }

    if (err.message.includes('API key')) {
      return res.status(401).json({ error: 'Invalid API key — check your .env file' });
    }

    return res.status(500).json({ error: 'Something went wrong — please try again' });
  }
};

const resetSession = (req, res) => {
  try {
    const { sessionId } = req.body;

    if (!sessionId) {
      return res.status(400).json({ error: 'Session ID is required' });
    }

    deleteSession(sessionId);
    delete conversationHistories[sessionId];

    return res.status(200).json({ message: 'Session cleared successfully' });

  } catch (err) {
    console.error('Reset error:', err.message);
    return res.status(500).json({ error: 'Failed to reset session' });
  }
};

module.exports = { chat, resetSession };
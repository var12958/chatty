const axios = require('axios');

const EMBEDDING_URL = `https://generativelanguage.googleapis.com/v1beta/models/text-embedding-004:embedContent`;

// Embed a single text string
const embedText = async (text) => {
  try {
    const res = await axios.post(
      `${EMBEDDING_URL}?key=${process.env.GEMINI_API_KEY}`,
      {
        model: 'models/text-embedding-004',
        content: { parts: [{ text }] }
      }
    );
    return res.data.embedding.values;
  } catch (err) {
    console.error('Embedding error:', err.message);
    throw new Error('Failed to generate embedding');
  }
};

// Embed multiple chunks with delay to avoid rate limit
const embedChunks = async (chunks) => {
  console.log(`Embedding ${chunks.length} chunks...`);
  const embedded = [];

  for (const chunk of chunks) {
    try {
      const vector = await embedText(chunk.text);
      embedded.push({ ...chunk, vector });

      // Small delay to avoid rate limiting
      await new Promise(r => setTimeout(r, 100));
    } catch (err) {
      console.warn(`⚠️ Skipping chunk ${chunk.id} — embedding failed`);
    }
  }

  console.log(`✓ Embedded ${embedded.length} chunks successfully`);
  return embedded;
};

module.exports = { embedText, embedChunks };